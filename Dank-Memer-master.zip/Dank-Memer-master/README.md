<p align="center">
<a title="memes" href=""><img src="https://cdn.discordapp.com/attachments/397477727214632971/434218636442337300/dmlogooo.png"></a>
</p>
<p align="center">
<a href="https://discordbots.org/bot/270904126974590976">
  <img src="https://discordbots.org/api/widget/servers/270904126974590976.svg?noavatar=true" />
</a>
<a href="https://discordbots.org/bot/270904126974590976" >
  <img src="https://discordbots.org/api/widget/status/270904126974590976.svg?noavatar=true" alt="Discord Meme Bot" />
</a>
<a href="https://discordbots.org/bot/270904126974590976" >
  <img src="https://discordbots.org/api/widget/lib/270904126974590976.svg?noavatar=true" alt="Discord Meme Bot" />
</a>
<a href="https://discordbots.org/bot/270904126974590976" >
  <img src="https://discordbots.org/api/widget/upvotes/270904126974590976.svg?noavatar=true" alt="Discord Meme Bot" />
</a>
</p>

<p align="center">
A discord bot bringing joy to hundreds of thousands of servers near you.
</p>


## Self hosting the bot

We do not support or encourage self hosting of this bot. The code is here for learning and transparency purposes.

As long as you follow the license, we don't care if you host your own version of Dank Memer. However, we will not be taking the time to help set it up.

## Authors

* **Melmsie** - *Initial work and owner* - [GitHub Profile](https://github.com/melmsie)
* **Aetheryx** - *I like trains* - [GitHub Profile](https://github.com/Aetheryx)
* **CyberRonin** - *Melmsie is my lover* [Github Profile](https://github.com/TheCyberRonin)
* **Ken** - *Haha yes* - [GitHub Profile](https://github.com/NotWeeb)
* **Kromatic** - *Mayonnaise is an instrument* [Github Profile](https://github.com/Devoxin)

See also the list of [contributors](https://github.com/melmsie/Dank-Memer/contributors) who participated in this project.

## License

This project is licensed under the GNU AGPLv3 License - see the [LICENSE.md](LICENSE.md) file for exact details, but basically if you take my work, give me credit. You also need to have your application that uses my code under the same license.

## Acknowledgments

* **Stupid Cat** - *Original author of the backend code for the trigger command* - [GitHub Profile](https://github.com/Ratismal)
* **Sporks** - *Went through 800 meme templates to give everyone a better experience <3*
